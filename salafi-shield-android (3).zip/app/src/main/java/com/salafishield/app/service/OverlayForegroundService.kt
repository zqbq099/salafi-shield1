package com.salafishield.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.salafishield.app.MainActivity

class OverlayForegroundService : Service() {

    companion object {
        const val CHANNEL_ID          = "salafi_shield_channel"
        const val NOTIFICATION_ID     = 1001
        const val ACTION_TOGGLE       = "com.salafishield.ACTION_TOGGLE"
        const val ACTION_SET_BLUR     = "com.salafishield.ACTION_SET_BLUR"
        const val EXTRA_BLUR_INTENSITY = "blur_intensity"

        private val COLOR_ON  = Color.parseColor("#1A3A5C")
        private val COLOR_OFF = Color.parseColor("#8B0000")
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var floatingButton: TextView? = null
    private var isShieldActive = false
    private var blurIntensity = 70

    // ── Lifecycle ────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        addBlurOverlay()
        addFloatingButton()
        activateShield()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE   -> toggleShield()
            ACTION_SET_BLUR -> {
                blurIntensity = intent.getIntExtra(EXTRA_BLUR_INTENSITY, 70)
                updateBlurIntensity()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        safeRemoveView(overlayView)
        safeRemoveView(floatingButton)
    }

    // ── Overlay Layer ─────────────────────────────────────────
    private fun addBlurOverlay() {
        overlayView = buildOverlayView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(overlayView, params)
        overlayView?.visibility = View.GONE
    }

    private fun buildOverlayView(): View {
        val view = View(this)
        applyBlurToView(view)
        return view
    }

    private fun applyBlurToView(view: View) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val radius = (blurIntensity / 100f) * 25f + 2f
            view.setRenderEffect(
                RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
            )
        }
        val alpha = ((blurIntensity / 100f) * 220).toInt()
        view.setBackgroundColor(Color.argb(alpha, 5, 10, 20))
    }

    private fun updateBlurIntensity() {
        overlayView?.let { applyBlurToView(it) }
    }

    // ── Floating Button ───────────────────────────────────────
    private fun addFloatingButton() {
        floatingButton = TextView(this).apply {
            text = "🛡️"
            textSize = 24f
            gravity = Gravity.CENTER
            setBackgroundColor(COLOR_ON)
            setPadding(24, 24, 24, 24)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24; y = 300
        }

        windowManager.addView(floatingButton, params)

        var initialX = 0; var initialY = 0
        var initialTouchX = 0f; var initialTouchY = 0f

        floatingButton?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager.updateViewLayout(floatingButton, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = Math.abs(event.rawX - initialTouchX)
                    val dy = Math.abs(event.rawY - initialTouchY)
                    if (dx < 12 && dy < 12) toggleShield()
                    true
                }
                else -> false
            }
        }
    }

    // ── Toggle ────────────────────────────────────────────────
    private fun activateShield() {
        isShieldActive = true
        overlayView?.visibility = View.VISIBLE
        floatingButton?.apply {
            text = "🛡️"
            setBackgroundColor(COLOR_ON)
        }
        vibrate()
        refreshNotification()
    }

    private fun toggleShield() {
        isShieldActive = !isShieldActive
        overlayView?.visibility = if (isShieldActive) View.VISIBLE else View.GONE
        floatingButton?.apply {
            text = if (isShieldActive) "🛡️" else "🔓"
            setBackgroundColor(if (isShieldActive) COLOR_ON else COLOR_OFF)
        }
        vibrate()
        refreshNotification()
    }

    // ── Notification ──────────────────────────────────────────
    private fun buildNotification(): Notification {
        val tapIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayForegroundService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val statusText = if (isShieldActive) "🛡️ نشط — الصور مشوّشة" else "🔓 متوقف — الصور ظاهرة"
        val actionLabel = if (isShieldActive) "إيقاف" else "تفعيل"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("درع السلفي")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(tapIntent)
            .addAction(0, actionLabel, toggleIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "درع السلفي", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "خدمة التشويش الدائمة" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun refreshNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    // ── Helpers ───────────────────────────────────────────────
    private fun vibrate() {
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") vib.vibrate(60)
        }
    }

    private fun safeRemoveView(view: View?) {
        try { view?.let { windowManager.removeView(it) } } catch (_: Exception) {}
    }
}