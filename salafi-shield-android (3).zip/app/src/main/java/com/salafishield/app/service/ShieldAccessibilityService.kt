package com.salafishield.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ShieldAccessibilityService : AccessibilityService() {

    companion object {
        private val BLOCKED_CLASS_SUFFIXES = listOf(
            "ImageView", "VideoView", "VideoPlayer", "MediaView",
            "ThumbnailView", "AvatarView", "ProfileImageView",
            "SimpleDraweeView", "PhotoView", "AppCompatImageView"
        )
        private val BLOCKED_RESOURCE_KEYWORDS = listOf(
            "avatar", "profile_image", "photo", "thumbnail",
            "video", "media", "story_image", "cover", "image"
        )
    }

    private lateinit var windowManager: WindowManager
    private val maskViews = mutableMapOf<String, View>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100L
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val targets = mutableListOf<AccessibilityNodeInfo>()
        collectTargets(root, targets)
        applyMasks(targets)
        targets.forEach { it.recycle() }
        root.recycle()
    }

    override fun onInterrupt() = clearMasks()
    override fun onDestroy() { super.onDestroy(); clearMasks() }

    private fun collectTargets(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (shouldMask(node)) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectTargets(child, out)
            child.recycle()
        }
    }

    private fun shouldMask(node: AccessibilityNodeInfo): Boolean {
        val cls = node.className?.toString() ?: return false
        val rid = node.viewIdResourceName ?: ""
        if (BLOCKED_CLASS_SUFFIXES.any { cls.endsWith(it) }) return true
        if (BLOCKED_RESOURCE_KEYWORDS.any { rid.contains(it, ignoreCase = true) }) return true
        return false
    }

    private fun applyMasks(targets: List<AccessibilityNodeInfo>) {
        val seen = mutableSetOf<String>()
        for (node in targets) {
            val b = Rect()
            node.getBoundsInScreen(b)
            if (b.isEmpty || b.width() < 10 || b.height() < 10) continue
            val key = "${node.viewIdResourceName}_${b.left}_${b.top}_${b.width()}_${b.height()}"
            seen.add(key)
            if (maskViews.containsKey(key)) {
                val lp = maskViews[key]!!.layoutParams as? WindowManager.LayoutParams ?: continue
                lp.x = b.left; lp.y = b.top; lp.width = b.width(); lp.height = b.height()
                try { windowManager.updateViewLayout(maskViews[key], lp) } catch (_: Exception) {}
            } else {
                val mask = buildMask()
                maskViews[key] = mask
                try { windowManager.addView(mask, buildParams(b)) } catch (_: Exception) {}
            }
        }
        (maskViews.keys - seen).forEach { key ->
            try { windowManager.removeView(maskViews[key]) } catch (_: Exception) {}
            maskViews.remove(key)
        }
    }

    private fun buildMask(): View {
        val v = View(this)
        v.setBackgroundColor(android.graphics.Color.argb(210, 5, 10, 20))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            v.setRenderEffect(
                android.graphics.RenderEffect.createBlurEffect(
                    22f, 22f, android.graphics.Shader.TileMode.CLAMP
                )
            )
        }
        return v
    }

    private fun buildParams(b: Rect) = WindowManager.LayoutParams(
        b.width(), b.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = b.left; y = b.top }

    private fun clearMasks() {
        maskViews.values.forEach { try { windowManager.removeView(it) } catch (_: Exception) {} }
        maskViews.clear()
    }
}