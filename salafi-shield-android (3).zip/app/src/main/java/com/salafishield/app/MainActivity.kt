package com.salafishield.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.salafishield.app.service.OverlayForegroundService

class MainActivity : AppCompatActivity() {

    private lateinit var masterSwitch: Switch
    private lateinit var shieldStatusText: TextView
    private lateinit var blurSeekBar: SeekBar
    private lateinit var blurValueText: TextView
    private lateinit var sessionTimer: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnAccessibility: Button

    private val handler = Handler(Looper.getMainLooper())
    private var sessionSeconds = 0L
    private var timerRunning = false

    private val timerRunnable = object : Runnable {
        override fun run() {
            if (timerRunning) {
                sessionSeconds++
                val h = sessionSeconds / 3600
                val m = (sessionSeconds % 3600) / 60
                val s = sessionSeconds % 60
                sessionTimer.text = String.format("%02d:%02d:%02d", h, m, s)
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        masterSwitch      = findViewById(R.id.masterSwitch)
        shieldStatusText  = findViewById(R.id.shieldStatusText)
        blurSeekBar       = findViewById(R.id.blurSeekBar)
        blurValueText     = findViewById(R.id.blurValueText)
        sessionTimer      = findViewById(R.id.sessionTimer)
        btnOverlay        = findViewById(R.id.btnOverlayPermission)
        btnAccessibility  = findViewById(R.id.btnAccessibilityPermission)

        setupMasterSwitch()
        setupBlurSlider()
        setupPermissionButtons()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionButtons()
    }

    // ── Master Switch ────────────────────────────────────────
    private fun setupMasterSwitch() {
        masterSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!hasOverlayPermission() || !hasAccessibilityPermission()) {
                    masterSwitch.isChecked = false
                    Toast.makeText(this, "يرجى منح الإذونين أولاً", Toast.LENGTH_SHORT).show()
                    return@setOnCheckedChangeListener
                }
                startShieldService()
                shieldStatusText.text = "🟢 الدرع نشط — جميع الصور مشوّشة"
                shieldStatusText.setTextColor(getColor(R.color.primary))
                startTimer()
            } else {
                stopShieldService()
                shieldStatusText.text = "⚪ الدرع متوقف"
                shieldStatusText.setTextColor(getColor(R.color.text_secondary))
                stopTimer()
            }
        }
    }

    // ── Blur Slider ──────────────────────────────────────────
    private fun setupBlurSlider() {
        blurSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                blurValueText.text = "$progress%"
                // Send blur intensity to running service
                val intent = Intent(this@MainActivity, OverlayForegroundService::class.java)
                intent.action = OverlayForegroundService.ACTION_SET_BLUR
                intent.putExtra(OverlayForegroundService.EXTRA_BLUR_INTENSITY, progress)
                startService(intent)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    // ── Permission Buttons ───────────────────────────────────
    private fun setupPermissionButtons() {
        btnOverlay.setOnClickListener {
            if (!hasOverlayPermission()) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        btnAccessibility.setOnClickListener {
            if (!hasAccessibilityPermission()) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    private fun updatePermissionButtons() {
        btnOverlay.text = if (hasOverlayPermission())
            "✅ إذن الظهور فوق التطبيقات — ممنوح"
        else
            "⚠️ إذن الظهور فوق التطبيقات — اضغط للمنح"

        btnAccessibility.text = if (hasAccessibilityPermission())
            "✅ إذن إمكانية الوصول — ممنوح"
        else
            "⚠️ إذن إمكانية الوصول — اضغط للمنح"
    }

    // ── Service Controls ─────────────────────────────────────
    private fun startShieldService() {
        val intent = Intent(this, OverlayForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopShieldService() {
        stopService(Intent(this, OverlayForegroundService::class.java))
    }

    // ── Permission Checks ────────────────────────────────────
    private fun hasOverlayPermission() =
        Settings.canDrawOverlays(this)

    private fun hasAccessibilityPermission(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("com.salafishield.app/.service.ShieldAccessibilityService")
    }

    // ── Session Timer ────────────────────────────────────────
    private fun startTimer() {
        sessionSeconds = 0
        timerRunning = true
        handler.post(timerRunnable)
    }

    private fun stopTimer() {
        timerRunning = false
        handler.removeCallbacks(timerRunnable)
        sessionTimer.text = "00:00:00"
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(timerRunnable)
    }
}