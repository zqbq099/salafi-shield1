# Keep accessibility service
-keep class com.salafishield.app.service.ShieldAccessibilityService { *; }
-keep class com.salafishield.app.service.OverlayForegroundService { *; }
-keep class com.salafishield.app.receiver.BootReceiver { *; }